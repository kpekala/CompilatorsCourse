# assignment operators
# binary operators
# transposition
B = 1
C = -A;     # assignemnt with unary expression
C = B' ;    # assignemnt with matrix transpose

C = A + B;

C = A + B + B;

